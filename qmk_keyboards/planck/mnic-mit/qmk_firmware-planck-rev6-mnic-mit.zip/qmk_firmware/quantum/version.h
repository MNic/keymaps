#define QMK_VERSION "e1a702-dirty"
#define QMK_BUILDDATE "2021-03-23-03:35:21"
#define CHIBIOS_VERSION "breaking_2021_q1"
#define CHIBIOS_CONTRIB_VERSION "breaking_2021_q1"